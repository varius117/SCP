# S.C.P (application Android)

Application Android non officielle qui embarque le site « S.C.P » (univers de la Fondation SCP, CC BY-SA 3.0).

## Obtenir l'APK
Chaque envoi sur la branche `main` compile automatiquement l'application (onglet **Actions**)
et publie le fichier `.apk` dans l'onglet **Releases**. Ouvrez la dernière Release depuis votre
téléphone et téléchargez le fichier `.apk`.

## Mettre à jour le contenu
Remplacez `app/src/main/assets/index.html` par la nouvelle version du site, puis envoyez la
modification : une nouvelle APK est produite et s'installe par-dessus l'ancienne.

## Compiler soi-même (optionnel)
Ouvrez le dossier dans Android Studio, puis **Build > Build App Bundle(s) / APK(s) > Build APK(s)**.
