package fr.dossier.scpfan;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {

    private WebView web;
    private boolean fullscreen = false;

    /** Pont appelé par la page : plein écran depuis les paramètres. */
    public class ScpBridge {
        @JavascriptInterface
        public void setFullscreen(final boolean on) {
            runOnUiThread(() -> applyFullscreen(on));
        }

        @JavascriptInterface
        public boolean isFullscreen() {
            return fullscreen;
        }
    }

    @SuppressWarnings("deprecation")
    private void applyFullscreen(boolean on) {
        fullscreen = on;
        View decor = getWindow().getDecorView();
        if (on) {
            decor.setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                    | View.SYSTEM_UI_FLAG_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        } else {
            decor.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        web = new WebView(this);
        web.setBackgroundColor(0xFF111416);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        // La musique peut démarrer sans toucher l'écran.
        s.setMediaPlaybackRequiresUserGesture(false);

        web.addJavascriptInterface(new ScpBridge(), "ScpApp");

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String scheme = uri.getScheme();
                // Les liens externes (wikis SCP, licence) s'ouvrent dans le navigateur.
                if ("http".equals(scheme) || "https".equals(scheme)) {
                    startActivity(new Intent(Intent.ACTION_VIEW, uri));
                    return true;
                }
                return false;
            }
        });

        if (savedInstanceState != null) {
            web.restoreState(savedInstanceState);
        } else {
            web.loadUrl("file:///android_asset/index.html");
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        // Couper la musique quand l'appli passe en arrière-plan.
        web.evaluateJavascript("window.scpPause&&scpPause()", null);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (fullscreen) applyFullscreen(true);
        web.evaluateJavascript("window.scpResume&&scpResume()", null);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus && fullscreen) applyFullscreen(true);
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        web.saveState(outState);
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }
}
