plugins {
    id("com.android.application")
}

// Le numéro de version augmente à chaque compilation sur GitHub,
// pour que chaque nouvelle APK s'installe par-dessus l'ancienne.
val buildNumber = (System.getenv("GITHUB_RUN_NUMBER") ?: "1").toInt()

android {
    namespace = "fr.dossier.scpfan"
    compileSdk = 34

    defaultConfig {
        applicationId = "fr.dossier.scpfan"
        minSdk = 26
        targetSdk = 34
        versionCode = buildNumber
        versionName = "1.$buildNumber"
    }

    signingConfigs {
        create("release") {
            storeFile = file("scp-release.jks")
            storePassword = "scpfondation"
            keyAlias = "scp"
            keyPassword = "scpfondation"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("release")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
