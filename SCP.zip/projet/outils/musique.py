"""Copie les musiques du dossier `musique/` du dépôt dans l'appli
et génère la liste de lecture (musique/playlist.js) lue par la page.

Pour associer une musique à une partie du site, commencez le nom du fichier
par le nom de la section suivi de " - ", par exemple :
    origines - Menu Ambience.mp3
    scp - Light Containment Zone.ogg
Sections reconnues : origines, scp, classe-d, sites, personnel, fim, gdi, annexe.
Sans préfixe, la musique est simplement ajoutée à la liste."""
import json, os, re, shutil, sys, unicodedata

SECTIONS = {
    "origines": "origins", "accueil": "origins",
    "scp": "objects", "objets": "objects",
    "classe-d": "class-d", "classe d": "class-d", "classed": "class-d",
    "sites": "sites", "securite": "sites", "sécurité": "sites",
    "personnel": "staff",
    "fim": "mtf", "mtf": "mtf",
    "gdi": "goi", "groupes": "goi",
    "annexe": "culture", "culture": "culture",
}
EXT = (".mp3", ".ogg", ".wav", ".m4a", ".aac", ".opus", ".flac")


def slug(s):
    s = unicodedata.normalize("NFKD", s).encode("ascii", "ignore").decode()
    return re.sub(r"[^A-Za-z0-9]+", "-", s).strip("-").lower() or "piste"


def titre_propre(t):
    t = t.replace("_", " ")
    t = re.sub(r"^\s*SCP\s*[-:]?\s*Containment Breach\s*[-:]\s*", "", t, flags=re.I)
    return re.sub(r"\s+", " ", t).strip()


src, dst = sys.argv[1], sys.argv[2]
os.makedirs(dst, exist_ok=True)
fichiers = []
if os.path.isdir(src):
    fichiers = [n for n in os.listdir(src) if n.lower().endswith(EXT)]
if not fichiers:
    # Pas de dossier « musique » dans le dépôt : on garde les musiques déjà incluses dans le zip.
    print("Aucune musique supplémentaire dans le dépôt : musiques du zip conservées.")
    for n in sorted(os.listdir(dst)):
        print(" -", n)
    sys.exit(0)

pistes, vus = [], set()
for nom in sorted(fichiers, key=str.lower):
    base, ext = os.path.splitext(nom)
    section, titre = "", base
    m = re.match(r"^\s*([^-]+?)\s+-\s+(.+)$", base)
    if m and m.group(1).strip().lower() in SECTIONS:
        section, titre = SECTIONS[m.group(1).strip().lower()], m.group(2)
    titre = titre_propre(titre)
    cible = slug(base) + ext.lower()
    while cible in vus:
        cible = "x-" + cible
    vus.add(cible)
    shutil.copy2(os.path.join(src, nom), os.path.join(dst, cible))
    pistes.append({"file": cible, "title": titre, "section": section})

with open(os.path.join(dst, "playlist.js"), "w", encoding="utf-8") as f:
    f.write("window.SCP_PLAYLIST=" + json.dumps(pistes, ensure_ascii=False) + ";\n")
print(f"{len(pistes)} musique(s) ajoutée(s) :")
for p in pistes:
    print(f" - {p['file']}  →  « {p['title']} »  section : {p['section'] or '(aucune)'}")
