# S.C.P

Application non officielle sur l'univers de la Fondation SCP (textes résumés, CC BY-SA 3.0).

- `app/` : application Android (le site est dans `app/src/main/assets/index.html`)
- `desktop/` : application PC Windows (Electron)

Chaque envoi de `SCP.zip` sur la branche `main` compile l'APK et le .exe,
puis les publie ensemble dans l'onglet **Releases**.
